/* eslint-disable */
import App from "./js/client";