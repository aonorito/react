/* eslint-disable */
import React from "react";
import { connect } from "react-redux";
import Constants from "../../libs/common/Constants";
import { toggleClsAction } from "../../actions/clsActionActions";
import ToggleButtonTemplate from "../templates/ToggleButtonTemplate";

@connect((store) => {
  return {};
})
class ToggleTodoButton extends React.Component {
  render() {
    return (
      // ※編集必須
      <div></div>
    );
  }
  // ※編集必須
}
export default ToggleTodoButton;